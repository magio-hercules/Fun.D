package com.example.off;

public class DBInfo {
    int rank;
    String userId;
    String win;
    String lose;

    public DBInfo(int rank, String userId, String win, String lose) {
        this.rank = rank;
        this.userId = userId;
        this.win = win;
        this.lose = lose;
    }
}
