package com.example.bookmark.model;

public class BookmarkChannelItem {

}
