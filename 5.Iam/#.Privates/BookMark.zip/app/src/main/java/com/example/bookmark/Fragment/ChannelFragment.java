package com.example.bookmark.Fragment;

import androidx.fragment.app.Fragment;

public class ChannelFragment extends Fragment {
}
